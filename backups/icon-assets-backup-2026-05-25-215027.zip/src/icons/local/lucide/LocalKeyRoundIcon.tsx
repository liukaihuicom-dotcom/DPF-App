/* Vendored from lucide-react-native KeyRound; source license: ISC. */
import { LucideIconBase } from '../LucideIconBase';
import type { LocalIconProps } from '../types';

const iconNode = [
  [
    "path",
    {
      d: "M2.586 17.414A2 2 0 0 0 2 18.828V21a1 1 0 0 0 1 1h3a1 1 0 0 0 1-1v-1a1 1 0 0 1 1-1h1a1 1 0 0 0 1-1v-1a1 1 0 0 1 1-1h.172a2 2 0 0 0 1.414-.586l.814-.814a6.5 6.5 0 1 0-4-4z",
      key: "1s6t7t"
    }
  ],
  ["circle", { cx: "16.5", cy: "7.5", r: ".5", fill: "currentColor", key: "w0ekpg" }]
] as const;

export function LocalKeyRoundIcon(props: LocalIconProps) {
  return <LucideIconBase iconNode={iconNode} {...props} />;
}
